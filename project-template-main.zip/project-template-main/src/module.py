

def hello_world():
    print("hello world")

def hello_youtube():
    return "whatsup"