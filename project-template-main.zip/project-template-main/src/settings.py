
neo4j_connection_details={
    "url":"bolt://localhost:7687",
    "user":"hello",
    "password":"verysecurepassword"
}


def hello_youtube():
    return "whatsup"